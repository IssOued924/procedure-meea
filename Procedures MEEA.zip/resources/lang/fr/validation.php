<?php
return [
    'custom' => [
        'agents' => [
            'matricule' => [
                'unique' => 'Ce Matricule existe déjà !',
            ],
        ],
    ],

    // ... d'autres traductions de messages d'erreur standard ...
];
