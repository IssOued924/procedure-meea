<?php

return [


    'failed' => 'Nom d\'utilisateur ou Mot de passe incorrecte.',
    'throttle' => 'Trop de tentatives ont échouées. Veuillez réessayer dans :seconds seconds.',

];
