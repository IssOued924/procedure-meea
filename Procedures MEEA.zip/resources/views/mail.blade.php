<h2>Hello</h2> <br><br>
Vous avez recu un messsage de : {{ $name }} <br><br>
Details de l'utilisateur: <br><br>
Nom: {{ $name }} <br>
Email: {{ $email }} <br>
Phone: {{ $phone }} <br>
Sujet: {{ $subject }} <br>
Message: {{ $user_query }} <br><br>
Merci