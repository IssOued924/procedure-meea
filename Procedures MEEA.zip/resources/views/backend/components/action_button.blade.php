<div class='btn-group'>
        <a title="Voir Détail" href="{{ route('detail-demande', ['process' => 'P002', 'id_demande' => $id]) }}" class="btn btn-primary ">
                <i class="bi bi-eye"></i> </a>
</div>
