<footer id="footer">
    <div class="container">
        <div class="copyright">
            &copy; Copyright <span>MEEA</span>  @ {{ date('Y') }}
        </div>
    </div>
</footer
